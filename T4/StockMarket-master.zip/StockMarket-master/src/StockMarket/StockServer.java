package StockMarket;

/**
 * Generated from IDL interface "StockServer".
 *
 * @author JacORB IDL compiler V 3.1, 19-Aug-2012
 * @version generated at 23/06/2016 18:45:27
 */

public interface StockServer
	extends StockServerOperations, org.omg.CORBA.Object, org.omg.CORBA.portable.IDLEntity
{
}
